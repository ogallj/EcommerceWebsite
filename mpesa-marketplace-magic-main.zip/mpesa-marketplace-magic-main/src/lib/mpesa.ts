
interface STKPushParams {
  amount: number;
  phoneNumber: string;
}

export const initiateSTKPush = async ({ amount, phoneNumber }: STKPushParams) => {
  try {
    const response = await fetch("/api/mpesa/stkpush", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        amount,
        phoneNumber,
      }),
    });

    if (!response.ok) {
      throw new Error("Payment initiation failed");
    }

    const data = await response.json();
    return data;
  } catch (error) {
    console.error("M-Pesa payment error:", error);
    throw error;
  }
};
