
import { useState } from "react";
import { ProductCard } from "@/components/ProductCard";
import { CartDrawer } from "@/components/CartDrawer";
import { initiateSTKPush } from "@/lib/mpesa";
import { useToast } from "@/hooks/use-toast";

// Sample products data - replace with your actual products
const products = [
  {
    id: "1",
    name: "Premium Wireless Headphones",
    price: 12999,
    image: "https://images.unsplash.com/photo-1505740420928-5e560c06d30e",
    description: "High-quality wireless headphones with noise cancellation.",
  },
  {
    id: "2",
    name: "Smart Watch Pro",
    price: 24999,
    image: "https://images.unsplash.com/photo-1523275335684-37898b6baf30",
    description: "Advanced smartwatch with health monitoring features.",
  },
  {
    id: "3",
    name: "4K Ultra HD Camera",
    price: 89999,
    image: "https://images.unsplash.com/photo-1526170375885-4d8ecf77b99f",
    description: "Professional-grade camera for stunning photography.",
  },
  {
    id: "4",
    name: "Laptop Pro 2024",
    price: 159999,
    image: "https://images.unsplash.com/photo-1496181133206-80ce9b88a853",
    description: "Powerful laptop for professionals and creators.",
  },
];

const Index = () => {
  const [cartItems, setCartItems] = useState<typeof products>([]);
  const { toast } = useToast();

  const handleAddToCart = (product: (typeof products)[0]) => {
    setCartItems([...cartItems, product]);
    toast({
      title: "Added to cart",
      description: `${product.name} has been added to your cart.`,
    });
  };

  const handleRemoveFromCart = (productId: string) => {
    setCartItems(cartItems.filter((item) => item.id !== productId));
  };

  const handleCheckout = async () => {
    try {
      // In a real application, you would get this from user input or saved data
      const phoneNumber = "254700000000";
      const total = cartItems.reduce((sum, item) => sum + item.price, 0);

      await initiateSTKPush({
        amount: total,
        phoneNumber,
      });

      toast({
        title: "Payment initiated",
        description: "Please check your phone for the M-Pesa prompt.",
      });
    } catch (error) {
      toast({
        title: "Payment failed",
        description: "There was an error processing your payment.",
        variant: "destructive",
      });
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="sticky top-0 z-50 border-b bg-white/80 backdrop-blur-sm">
        <div className="container flex h-16 items-center justify-between">
          <h1 className="text-2xl font-bold">Tech Store</h1>
          <CartDrawer
            cartItems={cartItems}
            onRemoveFromCart={handleRemoveFromCart}
            onCheckout={handleCheckout}
          />
        </div>
      </header>

      <main className="container py-8">
        <section className="mb-8 text-center">
          <h2 className="text-3xl font-bold">Featured Products</h2>
          <p className="mt-2 text-muted-foreground">
            Discover our collection of premium tech products
          </p>
        </section>

        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {products.map((product) => (
            <ProductCard
              key={product.id}
              product={product}
              onAddToCart={handleAddToCart}
            />
          ))}
        </div>
      </main>
    </div>
  );
};

export default Index;
